/**
*
* This is sensor node interface
*
*/

public interface SENInterface {

}