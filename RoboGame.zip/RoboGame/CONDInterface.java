/**
*
* This is condition node interface
*
*/

public interface CONDInterface {
	public Boolean evaluate(Robot robot);
}