@SuppressWarnings("serial")
public class RobotInterruptedException extends RuntimeException {
}
